Synthetic test kit for VUPDATE unit tests.
